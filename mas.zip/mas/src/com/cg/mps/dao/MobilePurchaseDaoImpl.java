package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.dao.MobilePurchaseDaoImpl;
import com.cg.mps.dao.QueryMapper;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBConnection;
import com.cg.mps.bean.MobilesBean;
import com.cg.mps.bean.PurchaseDetailsBean;

public class MobilePurchaseDaoImpl implements IMobilePurchaseDao {

    
    private Logger logger =Logger.getLogger(MobilePurchaseDaoImpl.class);
    public MobilePurchaseDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}
    
    @Override
    public int addCustomer(PurchaseDetailsBean Pbean) throws MobileException {
        int CustomerId = -1;
        try{
        Connection con = DBConnection.getConnection();
        PreparedStatement pstmt = con.prepareStatement(QueryMapper.ADD_QUERY);
        pstmt.setString(1, Pbean.getCustomerName());
        pstmt.setString(2, Pbean.getCustomerMailId());
        pstmt.setString(3, Pbean.getCustomerPhoneNo());
        pstmt.setInt(4, Pbean.getMobileId());
        int result = pstmt.executeUpdate();
        if(result == 0)
        {
            logger.error("unable to insert record ");
            throw new MobileException("insert Fail");
        }
        pstmt = con.prepareStatement(QueryMapper.UPDATE_QUANTITY_QUERY);
        pstmt.setInt(1, Pbean.getMobileId());
        int result1 = pstmt.executeUpdate();
        if(result1 == 0)
        {
            logger.error("unable to update record ");
            throw new MobileException("Update Fail");
        }
        pstmt = con.prepareStatement(QueryMapper.SEQUENCE_QUERY);
        ResultSet rst = pstmt.executeQuery();
        if(rst.next())
        {
            CustomerId=rst.getInt(1);
        }
        else
        {
            logger.error("Unable to fetch sequence");
            throw new MobileException("Unable to fetch Sequence");
        }
       
        con.close();
    }catch(SQLException e)
    {
        CustomerId = -1;
        logger.error("SQL ERROR"+e.getMessage());
        throw new MobileException(e.getMessage());
        
    }
        logger.info("Customer added sucessfully");
        return CustomerId;
    }

    @Override
    public MobilesBean deleteMobiles(int MobileId) throws MobileException {
        MobilesBean Mbean = new MobilesBean();
        try{
        Connection con = DBConnection.getConnection();
        PreparedStatement pstmt = con.prepareStatement(QueryMapper.DELETE_QUERY);
        pstmt.setInt(1, MobileId);
        ResultSet rst = pstmt.executeQuery();
        if(rst.next())
        {
            Mbean.getMobileId();
            Mbean.getMobileName();
            Mbean.getMobilePrice();
            Mbean.getMobileQuantity();
        }
        else
        {
            throw new MobileException("Can't delete because of mobileid available in PurchaseDetails");
            //throw new MobileException("Id not Found");
        }
        con.close();
        }
        catch(SQLException e)
        {
            logger.error("SQL ERROR"+e.getMessage());
            throw new MobileException(e.getMessage());
        }
        logger.info("Customer deleted sucessfully");
        return Mbean;
    }

    @Override
    public List<MobilesBean> viewAllMobiles() throws MobileException {
        
        ArrayList<MobilesBean> mb = new ArrayList<MobilesBean>();
        try{
        Connection con = DBConnection.getConnection();
        PreparedStatement pstmt = con.prepareStatement(QueryMapper.VIEWALLMOBILES_QUERY);
        ResultSet rst = pstmt.executeQuery();
        while(rst.next()){
            MobilesBean Mbean = new MobilesBean();
            
            Mbean.setMobileId(rst.getInt(1));
            Mbean.setMobileName(rst.getString(2));
            Mbean.setMobilePrice(rst.getInt(3));
            Mbean.setMobileQuantity(rst.getInt(4));
            mb.add(Mbean);
        }
        con.close();
        }
        catch(SQLException e)
        {
            logger.error("SQL ERROR"+e.getMessage());
            throw new MobileException(e.getMessage());
        }
        logger.info("view successfull");
        return mb;
    }

    @Override
    public List<MobilesBean> priceRangeMobiles(MobilesBean Mbean)
            throws MobileException {
        ArrayList<MobilesBean> mb = new ArrayList<MobilesBean>();
        try{
        Connection con = DBConnection.getConnection();
        PreparedStatement pstmt = con.prepareStatement(QueryMapper.PRICERANGE_QUERY);
        pstmt.setInt(1, Mbean.getMin());
        pstmt.setInt(2, Mbean.getMax());
        ResultSet rst = pstmt.executeQuery();
        while(rst.next()){
            MobilesBean Mbean1 = new MobilesBean();
            
            Mbean1.setMobileId(rst.getInt(1));
            Mbean1.setMobileName(rst.getString(2));
            Mbean1.setMobilePrice(rst.getInt(3));
            Mbean1.setMobileQuantity(rst.getInt(4));
            mb.add(Mbean1);
        }
        con.close();
        }
        catch(SQLException e)
        {
            logger.error("SQL ERROR"+e.getMessage());
            throw new MobileException(e.getMessage());
        }
        logger.info("Price range");
        return mb;
    }

        
        
    
    
    /*@Override
    public int priceRangeMobiles(MobilesBean Mbean)throws MobileException {
        int MobileId = -1;
        try{
        Connection con = DBConnection.getConnection();
        PreparedStatement pstmt = con.prepareStatement(QueryMapper.PRICERANGE_QUERY);
        pstmt.setInt(1, Mbean.getMin());
        pstmt.setInt(2, Mbean.getMax());
        int result = pstmt.executeUpdate();
        if(result == 0)
        {
            logger.error("unable to insert record ");
            throw new MobileException("insert Fail");
        }
        //pstmt = con.prepareStatement(QueryMapper.SEQUENCE_QUERY);
        ResultSet rst = pstmt.executeQuery();
        if(rst.next())
        {
            MobileId=rst.getInt(1);
        }
        else
        {
            logger.error("Unable to fetch sequence");
            throw new MobileException("Unable to fetch Sequence");
        }
        con.close();
    }catch(SQLException e)
    {
        MobileId = -1;
        logger.error("SQL ERROR"+e.getMessage());
        throw new MobileException(e.getMessage());
        
    }
        return MobileId;
    }*/

}

