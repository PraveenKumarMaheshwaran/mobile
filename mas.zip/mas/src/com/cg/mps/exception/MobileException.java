package com.cg.mps.exception;

public class MobileException extends Exception{

	public MobileException(String message)
    {
        super(message);
    }
}
